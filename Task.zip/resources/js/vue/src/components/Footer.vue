<template>
  <footer>
    <hr class="footer-divider">

    <p> &copy; Copyright <span style="color:#2F5508; font-weight: 600;">Peak&Dale</span>. All Rights Reserved <br/>
        Designed by <span style="color: #81BE41">Peak&Dale</span></p>
  </footer>
</template>


<style scope>

  .footer-divider {
    position: inherit;
    margin-top: 5vh;
  }

  footer p {
    text-align: center;
    color: #2F5508;
  }

  footer {
    margin-bottom: -20px;
  }
</style>