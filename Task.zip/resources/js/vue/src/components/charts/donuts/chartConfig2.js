



export const data = {
  label: 'red',
  datasets: [
    {
      backgroundColor: ['#9C690C', '#d9d9d966'],
      data: [3, 4],
      borderWidth: 0
    }
  ]
}

export const options = {
  responsive: true,
  maintainAspectRatio: true,
}
