



export const data = {
  label: 'red',
  datasets: [
    {
      backgroundColor: ['#FFA500', '#d9d9d966'],
      data: [5, 3],
      borderWidth: 0
    }
  ]
}

export const options = {
  responsive: true,
  maintainAspectRatio: true,
}
