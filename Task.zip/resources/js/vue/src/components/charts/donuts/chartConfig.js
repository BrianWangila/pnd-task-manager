



export const data = {
  label: 'red',
  datasets: [
    {
      backgroundColor: ['#81BE41', '#d9d9d966'],
      data: [7, 2],
      borderWidth: 0
    }
  ]
}

export const options = {
  responsive: true,
  maintainAspectRatio: true,
}
