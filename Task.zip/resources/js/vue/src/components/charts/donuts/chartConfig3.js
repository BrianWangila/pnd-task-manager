



export const data = {
  label: 'red',
  datasets: [
    {
      backgroundColor: ['rgba(129, 190, 65, 0.6)', '#d9d9d966'],
      data: [6, 2],
      borderWidth: 0
    }
  ]
}

export const options = {
  responsive: true,
  maintainAspectRatio: true,
}
