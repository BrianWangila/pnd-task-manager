<?php

namespace Database\Seeders;
require_once 'vendor/autoload.php';

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\Project;

class ProjectSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $faker = \Faker\Factory::create('en_US');
        for ($i=0; $i < 10; $i++) { 
            Project::create([
                "project_title" => $faker->catchphrase(),
                "description"=> $faker->realText(),
                "deadline"=> $faker->dateTimeThisYear('+4 months'),
                "is_complete" => false
            ]);
        }

        
    }
}


