<?php



return [

  'home' => env('SPA_URL') . '/dashboard',
];